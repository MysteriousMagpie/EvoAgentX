declare module '*.cjs' {
  const config: any;
  export default config;
}
