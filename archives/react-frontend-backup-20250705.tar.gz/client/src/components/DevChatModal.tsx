import React, { useState, useEffect, useRef } from 'react';
import { API_URL } from '../api';

interface DevChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMessage?: string;
  projectPath?: string;
  onCodeApplied?: (changes: any) => void;
}



interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: {
    isCodePreview?: boolean;
    pendingApproval?: boolean;
    codeContent?: string;
    diffSummary?: string;
  };
}

export const DevChatModal: React.FC<DevChatModalProps> = ({
  isOpen,
  onClose,
  initialMessage = '',
  projectPath = '/default/project', 
  onCodeApplied
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState(initialMessage);
  const [isProcessing, setIsProcessing] = useState(false);
  const [pendingCode, setPendingCode] = useState<string | null>(null);
  const [pendingDiff, setPendingDiff] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Add initial message if provided
  useEffect(() => {
    if (isOpen && initialMessage && messages.length === 0) {
      setMessages([{
        id: '1',
        role: 'system',
        content: `Welcome to Conversational Development! 🛠️

I can help you:
• Create new components or features
• Modify existing code
• Fix bugs and issues
• Refactor and optimize code
• Add tests and documentation

Just describe what you want in natural language!`,
        timestamp: new Date()
      }]);
    }
  }, [isOpen, initialMessage, messages.length]);

  const parseDevRequest = async (message: string): Promise<any> => {
    try {
      const response = await fetch(`${API_URL}/api/obsidian/intelligence/parse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          context: {
            projectPath,
            parseType: 'development_request',
            mode: 'conversational'
          }
        })
      });

      if (!response.ok) throw new Error('Parse failed');
      return await response.json();
    } catch (error) {
      console.error('Parse error:', error);
      return {
        intent: 'modify',
        description: message,
        confidence: 0.5
      };
    }
  };

  const generateAndPreviewCode = async (request: any): Promise<void> => {
    try {
      const response = await fetch(`${API_URL}/api/obsidian/agents/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_type: 'code_generator',
          request: {
            ...request,
            projectPath,
            mode: 'conversational'
          }
        })
      });

      if (!response.ok) throw new Error('Code generation failed');
      
      const result = await response.json();
      const generated = result.data?.generatedCode || result.generatedCode;
      
      setPendingCode(generated.content);
      setPendingDiff(generated.diffSummary);

      const previewMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'assistant',
        content: `**Code Generated Successfully!** 🎉

${generated.diffSummary || 'Code changes are ready for review.'}

**What this does:**
${generated.explanations?.map((exp: string) => `• ${exp}`).join('\n') || '• Implements the requested changes'}

${generated.warnings?.length ? `\n**⚠️ Please Note:**\n${generated.warnings.map((w: string) => `• ${w}`).join('\n')}` : ''}

**Review the code below and let me know if you want to apply it!**`,
        timestamp: new Date(),
        metadata: {
          isCodePreview: true,
          pendingApproval: true,
          codeContent: generated.content,
          diffSummary: generated.diffSummary
        }
      };

      setMessages(prev => [...prev, previewMessage]);
      
    } catch (error) {
      throw new Error(`Code generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    try {
      // Check if this is an approval/rejection
      const lowerInput = input.toLowerCase().trim();
      if (pendingCode && (
        lowerInput.includes('yes') || lowerInput.includes('apply') || 
        lowerInput.includes('approve') || lowerInput === 'y'
      )) {
        await handleApplyCode();
        return;
      }
      
      if (pendingCode && (
        lowerInput.includes('no') || lowerInput.includes('reject') || 
        lowerInput.includes('cancel') || lowerInput === 'n'
      )) {
        handleRejectCode();
        return;
      }

      // Parse the development request
      const processingMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'system',
        content: '🔍 Analyzing your request...',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, processingMessage]);

      const parsed = await parseDevRequest(userMessage.content);
      
      // Show parsing results
      const parseMessage: ChatMessage = {
        id: (Date.now() + 2).toString(),
        role: 'assistant',
        content: `**Understanding your request:**

🎯 **Intent:** ${parsed.intent || 'modify'}
📁 **Target:** ${parsed.targetFile || 'Will auto-detect appropriate files'}
🎖️ **Confidence:** ${parsed.confidence ? (parsed.confidence * 100).toFixed(0) + '%' : 'Processing'}

${parsed.confidence && parsed.confidence < 0.7 ? 
  '⚠️ I may need clarification, but let me try generating code first...' : 
  '✅ Clear request! Generating code...'}`,
        timestamp: new Date()
      };

      setMessages(prev => prev.slice(0, -1).concat([parseMessage]));

      // Generate code
      const generatingMessage: ChatMessage = {
        id: (Date.now() + 3).toString(),
        role: 'system',
        content: '⚙️ Generating code changes...',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, generatingMessage]);

      await generateAndPreviewCode(parsed);
      
      // Remove the "generating" message
      setMessages(prev => prev.slice(0, -1));

    } catch (error) {
      const errorMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'system',
        content: `❌ **Error:** ${error instanceof Error ? error.message : 'Something went wrong'}

Please try rephrasing your request or being more specific about what you want to change.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApplyCode = async () => {
    if (!pendingCode) return;
    
    setIsProcessing(true);
    try {
      const response = await fetch(`${API_URL}/api/obsidian/workflow/apply-changes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          changes: {
            content: pendingCode,
            projectPath,
            diffSummary: pendingDiff
          }
        })
      });

      if (!response.ok) throw new Error('Failed to apply changes');
      
      const result = await response.json();
      onCodeApplied?.(result);

      const successMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'system',
        content: `✅ **Changes Applied Successfully!**

Your codebase has been updated. The plugin will reload automatically to reflect the changes.

Is there anything else you'd like to modify?`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, successMessage]);
      setPendingCode(null);
      setPendingDiff(null);

    } catch (error) {
      const errorMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'system',
        content: `❌ **Failed to apply changes:** ${error instanceof Error ? error.message : 'Unknown error'}

Please try again or make a different request.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectCode = () => {
    setPendingCode(null);
    setPendingDiff(null);

    const rejectMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'system',
      content: `❌ **Changes Rejected**

No problem! Feel free to:
• Request modifications to the approach
• Try a different implementation
• Ask for a completely different solution

What would you like to do instead?`,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, rejectMessage]);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl w-full max-w-4xl h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🛠️</span>
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Development Chat
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                AI-powered code generation and modification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-2xl"
          >
            ×
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : message.role === 'system'
                  ? 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                  : 'bg-gray-50 dark:bg-gray-750 text-gray-900 dark:text-gray-100'
              }`}>
                <div className="whitespace-pre-wrap">{message.content}</div>
                
                {/* Code preview */}
                {message.metadata?.isCodePreview && message.metadata.codeContent && (
                  <div className="mt-4 bg-gray-900 rounded-lg p-4 border">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-300">Generated Code</span>
                      <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">Preview</span>
                    </div>
                    <pre className="text-sm text-gray-300 overflow-x-auto max-h-48 overflow-y-auto">
                      <code>{message.metadata.codeContent}</code>
                    </pre>
                    {message.metadata.pendingApproval && (
                      <div className="flex gap-3 mt-4">
                        <button
                          onClick={handleApplyCode}
                          disabled={isProcessing}
                          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition disabled:opacity-50"
                        >
                          {isProcessing ? 'Applying...' : 'Apply Changes ✅'}
                        </button>
                        <button
                          onClick={handleRejectCode}
                          disabled={isProcessing}
                          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition disabled:opacity-50"
                        >
                          Reject ❌
                        </button>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex justify-start">
              <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 flex items-center gap-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  AI is working on your request...
                </span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex gap-3">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                pendingCode 
                  ? "Type 'yes' to apply or 'no' to reject the changes..."
                  : "Describe the code changes you want... (Ctrl+Enter to send)"
              }
              className="flex-1 resize-none rounded-lg border border-gray-300 dark:border-gray-600 px-3 py-2 
                       bg-white dark:bg-gray-700 text-gray-900 dark:text-white
                       focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={2}
              disabled={isProcessing}
            />
            <button
              onClick={handleSendMessage}
              disabled={!input.trim() || isProcessing}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 
                       transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Send
            </button>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-2 flex justify-between">
            <span>💡 Be specific about files and features for best results</span>
            <span>Ctrl+Enter to send</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DevChatModal;
