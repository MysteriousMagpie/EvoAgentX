import React, { useState, useEffect, useRef } from 'react';
import { API_URL } from '../api';

// === Types for Conversational Development Interface ===

interface ParsedDevRequest {
  intent: 'create' | 'modify' | 'delete' | 'refactor' | 'add_feature' | 'fix_bug' | 'optimize';
  targetFile?: string;
  description: string;
  confidence: number;
  requiredFiles?: string[];
  suggestedApproach?: string;
}

interface GeneratedCode {
  type: 'patch' | 'full_file' | 'multiple_files';
  content: string | Record<string, string>;
  diffSummary?: string;
  explanations?: string[];
  warnings?: string[];
}

interface DevChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: {
    isDevRequest?: boolean;
    parsedRequest?: ParsedDevRequest;
    generatedCode?: GeneratedCode;
    applied?: boolean;
  };
}

interface ConversationalDevelopmentProps {
  projectPath?: string;
  onCodeApplied?: (changes: any) => void;
}

export const ConversationalDevelopment: React.FC<ConversationalDevelopmentProps> = ({
  projectPath = '/default/project',
  onCodeApplied
}) => {
  const [messages, setMessages] = useState<DevChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [pendingCode, setPendingCode] = useState<GeneratedCode | null>(null);
  const [pendingRequest, setPendingRequest] = useState<ParsedDevRequest | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // === Core Functions ===

  const parseDevRequest = async (userMessage: string): Promise<ParsedDevRequest> => {
    try {
      const response = await fetch(`${API_URL}/api/obsidian/intelligence/parse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          context: {
            projectPath,
            parseType: 'development_request'
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Parse request failed: ${response.statusText}`);
      }

      const result = await response.json();
      return result.data || result;
    } catch (error) {
      console.error('Error parsing dev request:', error);
      // Fallback parsing
      return {
        intent: 'modify',
        description: userMessage,
        confidence: 0.5,
        suggestedApproach: 'Manual review required'
      };
    }
  };

  const generateCode = async (request: ParsedDevRequest): Promise<GeneratedCode> => {
    try {
      const response = await fetch(`${API_URL}/api/obsidian/agents/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_type: 'code_generator',
          request: {
            intent: request.intent,
            targetFile: request.targetFile,
            description: request.description,
            context: {
              projectPath,
              requiredFiles: request.requiredFiles,
              approach: request.suggestedApproach
            }
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Code generation failed: ${response.statusText}`);
      }

      const result = await response.json();
      return result.data || result.generated_code;
    } catch (error) {
      console.error('Error generating code:', error);
      throw error;
    }
  };

  // === Helper Functions ===
  
  const generateCodePreviewMessage = (code: GeneratedCode): string => {
    let message = "Here's the generated code:\n\n";
    
    if (code.type === 'patch') {
      message += "```diff\n" + code.content + "\n```";
    } else if (code.type === 'full_file') {
      message += "```typescript\n" + code.content + "\n```";
    } else if (code.type === 'multiple_files') {
      message += "Multiple files will be modified:\n\n";
      Object.entries(code.content as Record<string, string>).forEach(([file, content]) => {
        message += `**${file}:**\n\`\`\`typescript\n${content.substring(0, 200)}...\n\`\`\`\n\n`;
      });
    }
    
    if (code.explanations && code.explanations.length > 0) {
      message += "\n**Explanation:**\n" + code.explanations.join('\n');
    }
    
    if (code.warnings && code.warnings.length > 0) {
      message += "\n**⚠️ Warnings:**\n" + code.warnings.join('\n');
    }
    
    message += "\n\nWould you like me to apply these changes?";
    return message;
  };

  // === Event Handlers ===

  const handleSendMessage = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: DevChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    try {
      // Step 1: Parse the development request
      const parsedRequest = await parseDevRequest(input);
      setPendingRequest(parsedRequest);

      // Add assistant message showing understanding
      const parseMessage: DevChatMessage = {
        id: `${Date.now()}-parse`,
        role: 'assistant',
        content: `I understand you want to **${parsedRequest.intent}** ${parsedRequest.targetFile ? `in \`${parsedRequest.targetFile}\`` : 'code'}.\n\n${parsedRequest.description}\n\nLet me generate the code for you...`,
        timestamp: new Date(),
        metadata: {
          isDevRequest: true,
          parsedRequest
        }
      };

      setMessages(prev => [...prev, parseMessage]);

      // Step 2: Generate code if confidence is high enough
      if (parsedRequest.confidence > 0.6) {
        const generatedCode = await generateCode(parsedRequest);
        setPendingCode(generatedCode);

        // Add code preview message
        const codeMessage: DevChatMessage = {
          id: `${Date.now()}-code`,
          role: 'assistant',
          content: generateCodePreviewMessage(generatedCode),
          timestamp: new Date(),
          metadata: {
            generatedCode,
            applied: false
          }
        };

        setMessages(prev => [...prev, codeMessage]);
      } else {
        // Ask for clarification
        const clarificationMessage: DevChatMessage = {
          id: `${Date.now()}-clarify`,
          role: 'assistant',
          content: `I need more information to help you. Could you be more specific about:\n\n${parsedRequest.suggestedApproach || 'What exactly you want to change'}`,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, clarificationMessage]);
      }

    } catch (error) {
      console.error('Error processing message:', error);
      const errorMessage: DevChatMessage = {
        id: `${Date.now()}-error`,
        role: 'assistant',
        content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApplyCode = async () => {
    if (!pendingCode || !pendingRequest) return;

    try {
      setIsProcessing(true);

      const response = await fetch(`${API_URL}/api/obsidian/workflow/apply-changes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: pendingCode,
          targetFile: pendingRequest.targetFile,
          projectPath,
          intent: pendingRequest.intent
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to apply changes: ${response.statusText}`);
      }

      const result = await response.json();

      // Update the last message to show success
      setMessages(prev => prev.map(msg => {
        if (msg.metadata?.generatedCode && !msg.metadata.applied) {
          return {
            ...msg,
            content: msg.content + '\n\n✅ **Applied successfully!**',
            metadata: { ...msg.metadata, applied: true }
          };
        }
        return msg;
      }));

      // Add success message
      const successMessage: DevChatMessage = {
        id: `${Date.now()}-success`,
        role: 'assistant',
        content: `Great! I've successfully applied the changes${pendingRequest.targetFile ? ` to \`${pendingRequest.targetFile}\`` : ''}. ${result.summary || 'The changes are now active.'}`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, successMessage]);

      // Call callback
      if (onCodeApplied) {
        onCodeApplied(result);
      }

      // Clear pending items
      setPendingCode(null);
      setPendingRequest(null);

    } catch (error) {
      console.error('Error applying code:', error);
      const errorMessage: DevChatMessage = {
        id: `${Date.now()}-apply-error`,
        role: 'assistant',
        content: `Failed to apply changes: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectCode = () => {
    setPendingCode(null);
    setPendingRequest(null);

    const rejectMessage: DevChatMessage = {
      id: `${Date.now()}-reject`,
      role: 'assistant',
      content: 'No problem! Feel free to ask for modifications or try a different approach.',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, rejectMessage]);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // === Render ===

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Development Chat</h2>
        <div className="text-sm text-gray-500">
          Project: {projectPath}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-gray-500">
            <p className="text-lg mb-2">👋 Hi! I'm your development assistant</p>
            <p>Tell me what you'd like to build, modify, or fix and I'll help you write the code!</p>
            <div className="mt-4 text-sm space-y-1">
              <p>Try saying:</p>
              <p>"Add a dark mode toggle to the settings"</p>
              <p>"Fix the API error handling in auth.service.ts"</p>
              <p>"Create a user authentication component"</p>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-3xl p-3 rounded-lg ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <div className="whitespace-pre-wrap">{message.content}</div>
              
              {/* Show action buttons for code messages */}
              {message.metadata?.generatedCode && !message.metadata.applied && (
                <div className="flex space-x-2 mt-3">
                  <button
                    onClick={handleApplyCode}
                    disabled={isProcessing}
                    className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 disabled:opacity-50"
                  >
                    Apply Changes
                  </button>
                  <button
                    onClick={handleRejectCode}
                    disabled={isProcessing}
                    className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700 disabled:opacity-50"
                  >
                    Reject
                  </button>
                </div>
              )}
              
              <div className="text-xs opacity-70 mt-1">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}

        {isProcessing && (
          <div className="flex justify-start">
            <div className="bg-gray-100 p-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="animate-spin w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                <span>Processing...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Describe what you want to build, modify, or fix..."
            className="flex-1 p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={3}
            disabled={isProcessing}
          />
          <button
            onClick={handleSendMessage}
            disabled={!input.trim() || isProcessing}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};
