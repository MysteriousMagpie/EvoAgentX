import React, { useState, useEffect } from 'react';
import { API_URL } from '../api';

interface InterpreterSelectorProps {
  code: string;
  onInterpreterChange: (interpreter: string, analysis?: any) => void;
  onExecute: (code: string, interpreter: string, options?: any) => void;
  disabled?: boolean;
}

interface CodeAnalysis {
  imports: string[];
  has_visualization: boolean;
  has_data_processing: boolean;
  security_risk_score: number;
  estimated_tokens: number;
  uses_files: boolean;
  complexity_score: number;
}

export const InterpreterSelector: React.FC<InterpreterSelectorProps> = ({
  code,
  onInterpreterChange,
  onExecute,
  disabled = false
}) => {
  const [selectedInterpreter, setSelectedInterpreter] = useState<string>('auto');
  const [analysis, setAnalysis] = useState<CodeAnalysis | null>(null);
  const [recommendation, setRecommendation] = useState<string>('');
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [loading, setLoading] = useState(false);

  const interpreters = [
    { value: 'auto', label: '🤖 Smart Auto-Select', description: 'AI chooses best interpreter' },
    { value: 'python', label: '🐍 Python Local', description: 'Fast local execution' },
    { value: 'docker', label: '🐳 Docker Sandbox', description: 'Secure containerized execution' },
    { value: 'openai', label: '☁️ OpenAI Cloud', description: 'Cloud execution with advanced libraries' }
  ];

  // Analyze code when it changes
  useEffect(() => {
    if (code.trim()) {
      analyzeCode();
    }
  }, [code]);

  const analyzeCode = async () => {
    if (!code.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/analyze-code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code })
      });

      if (response.ok) {
        const result = await response.json();
        setAnalysis(result.analysis);
        setRecommendation(result.recommended_interpreter);
        setEstimatedCost(result.estimated_cost);
      }
    } catch (error) {
      console.error('Failed to analyze code:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInterpreterChange = (interpreter: string) => {
    setSelectedInterpreter(interpreter);
    onInterpreterChange(interpreter, analysis);
  };

  const handleExecute = () => {
    const options = {
      security_level: 'medium',
      budget_limit: 5.0, // $5 limit
      visualization_needed: analysis?.has_visualization || false,
      performance_priority: false
    };
    
    onExecute(code, selectedInterpreter, options);
  };

  const getInterpreterIcon = (interpreter: string) => {
    if (interpreter === recommendation) {
      return '⭐';
    }
    return '';
  };

  const getRiskLevelColor = (score: number) => {
    if (score > 2) return 'text-red-600';
    if (score > 0) return 'text-yellow-600';
    return 'text-green-600';
  };

  return (
    <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Code Interpreter</h3>
        {loading && <div className="animate-spin w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full" />}
      </div>

      {/* Interpreter Selection */}
      <div className="grid grid-cols-1 gap-2">
        {interpreters.map((interpreter) => (
          <div
            key={interpreter.value}
            className={`p-3 border rounded-lg cursor-pointer transition-colors ${
              selectedInterpreter === interpreter.value
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-300 hover:border-gray-400'
            } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={() => !disabled && handleInterpreterChange(interpreter.value)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span>{interpreter.label}</span>
                {getInterpreterIcon(interpreter.value) && (
                  <span title="Recommended">{getInterpreterIcon(interpreter.value)}</span>
                )}
              </div>
              {interpreter.value === 'openai' && estimatedCost > 0 && (
                <span className="text-sm text-gray-600">~${estimatedCost.toFixed(4)}</span>
              )}
            </div>
            <p className="text-sm text-gray-600">{interpreter.description}</p>
          </div>
        ))}
      </div>

      {/* Code Analysis Display */}
      {analysis && (
        <div className="space-y-2 text-sm">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="font-medium">Complexity:</span>
              <span className="ml-2">{analysis.complexity_score > 15 ? 'High' : analysis.complexity_score > 5 ? 'Medium' : 'Low'}</span>
            </div>
            <div>
              <span className="font-medium">Security Risk:</span>
              <span className={`ml-2 ${getRiskLevelColor(analysis.security_risk_score)}`}>
                {analysis.security_risk_score > 2 ? 'High' : analysis.security_risk_score > 0 ? 'Medium' : 'Low'}
              </span>
            </div>
          </div>
          
          {analysis.has_visualization && (
            <div className="text-blue-600">📊 Contains visualization code</div>
          )}
          
          {analysis.has_data_processing && (
            <div className="text-green-600">📈 Contains data processing</div>
          )}
          
          {analysis.uses_files && (
            <div className="text-orange-600">📁 Requires file access</div>
          )}
          
          {analysis.imports.length > 0 && (
            <div>
              <span className="font-medium">Libraries:</span>
              <span className="ml-2">{analysis.imports.slice(0, 5).join(', ')}</span>
              {analysis.imports.length > 5 && <span> +{analysis.imports.length - 5} more</span>}
            </div>
          )}
        </div>
      )}

      {/* Recommendation */}
      {recommendation && recommendation !== selectedInterpreter && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2">
            <span>⭐</span>
            <span className="font-medium">Recommended:</span>
            <button
              className="text-blue-600 hover:text-blue-800 underline"
              onClick={() => handleInterpreterChange(recommendation)}
            >
              {interpreters.find(i => i.value === recommendation)?.label}
            </button>
          </div>
        </div>
      )}

      {/* Execute Button */}
      <button
        onClick={handleExecute}
        disabled={disabled || !code.trim()}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        Execute Code
      </button>
    </div>
  );
};
