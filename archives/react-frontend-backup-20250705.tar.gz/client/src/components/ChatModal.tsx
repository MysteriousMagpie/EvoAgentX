import React, { useState, useEffect, useRef, useCallback } from 'react';
import { API_URL } from '../api';
import ConversationalDevAPI, { executeDevWorkflow, initializeDevWebSocket } from './api-client';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectPath?: string;
  mode?: 'chat' | 'development';
  onCodeApplied?: (changes: any) => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: {
    type?: 'text' | 'code_preview' | 'error' | 'success';
    codeContent?: string;
    diffSummary?: string;
    parsedRequest?: any;
    generatedCode?: any;
    pendingApproval?: boolean;
    applied?: boolean;
  };
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  projectPath = '/default/project',
  mode = 'development',
  onCodeApplied
}) => {
  // === State Management ===
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentMode, setCurrentMode] = useState<'ask' | 'agent' | 'dev'>(mode === 'development' ? 'dev' : 'ask');
  const [conversationId, setConversationId] = useState<string>('');
  const [pendingApproval, setPendingApproval] = useState<any>(null);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  
  // === Refs ===
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const apiRef = useRef<ConversationalDevAPI | null>(null);

  // === Initialization ===
  useEffect(() => {
    if (isOpen) {
      // Initialize API client
      apiRef.current = new ConversationalDevAPI();
      
      // Generate conversation ID
      setConversationId(`conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
      
      // Initialize WebSocket for real-time updates
      if (mode === 'development') {
        initializeWebSocket();
      }
      
      // Add welcome message
      addWelcomeMessage();
      
      // Focus input
      setTimeout(() => inputRef.current?.focus(), 100);
    }
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [isOpen, mode]);

  // === WebSocket Management ===
  const initializeWebSocket = useCallback(() => {
    if (wsRef.current) return;
    
    setConnectionStatus('connecting');
    wsRef.current = initializeDevWebSocket('default', handleWebSocketMessage);
    
    if (wsRef.current) {
      wsRef.current.onopen = () => setConnectionStatus('connected');
      wsRef.current.onclose = () => setConnectionStatus('disconnected');
      wsRef.current.onerror = () => setConnectionStatus('disconnected');
    }
  }, []);

  const handleWebSocketMessage = useCallback((message: any) => {
    if (message.type === 'code_applied') {
      addSystemMessage('✅ Code changes have been applied successfully!', 'success');
    } else if (message.type === 'validation_result') {
      addSystemMessage(`Code validation: ${message.data.valid ? 'Passed' : 'Failed'}`, 
        message.data.valid ? 'success' : 'error');
    }
  }, []);

  // === Auto-scroll ===
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // === Helper Functions ===
  const addWelcomeMessage = () => {
    const welcomeContent = currentMode === 'dev' 
      ? `🛠️ **Welcome to Conversational Development!**

I can help you build and modify code using natural language. Here's what I can do:

**✨ Create New Features:**
• "Add a dark mode toggle to the settings page"
• "Create a user authentication component"
• "Build a contact form with validation"

**🔧 Modify Existing Code:**
• "Fix the API error handling in auth.service.ts"
• "Add loading states to the login form"
• "Optimize the image gallery performance"

**🚀 Advanced Operations:**
• "Refactor the dashboard to use React hooks"
• "Add unit tests for the user service"
• "Document the API endpoints"

Just describe what you want in natural language, and I'll generate the code for you!`
      : `💬 **AI Assistant Ready**

I'm here to help with questions, analysis, and general assistance. 

Switch to **Development Mode** if you want to generate or modify code.`;

    const welcomeMessage: ChatMessage = {
      id: 'welcome',
      role: 'system',
      content: welcomeContent,
      timestamp: new Date(),
      metadata: { type: 'text' }
    };

    setMessages([welcomeMessage]);
  };

  const addMessage = (role: ChatMessage['role'], content: string, metadata?: ChatMessage['metadata']): ChatMessage => {
    const message: ChatMessage = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      role,
      content,
      timestamp: new Date(),
      metadata
    };

    setMessages(prev => [...prev, message]);
    return message;
  };

  const addSystemMessage = (content: string, type: 'text' | 'error' | 'success' = 'text') => {
    addMessage('system', content, { type });
  };

  const updateMessage = (messageId: string, updates: Partial<ChatMessage>) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, ...updates } : msg
    ));
  };

  // === Chat Handlers ===
  const handleSendMessage = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage = addMessage('user', input.trim());
    setInput('');
    setIsProcessing(true);

    try {
      // Check for approval/rejection if there's pending code
      if (pendingApproval) {
        await handleApprovalResponse(input.trim().toLowerCase());
        return;
      }

      // Route to appropriate handler based on mode
      if (currentMode === 'dev') {
        await handleDevelopmentRequest(userMessage.content);
      } else {
        await handleChatRequest(userMessage.content);
      }

    } catch (error) {
      addSystemMessage(
        `❌ Error: ${error instanceof Error ? error.message : 'Something went wrong'}`,
        'error'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDevelopmentRequest = async (message: string) => {
    const processingMessage = addMessage('system', '🔍 Analyzing your development request...');

    try {
      // Execute the complete development workflow
      const result = await executeDevWorkflow(message, {
        projectPath,
        autoApply: false,
        onProgress: (step: string, data?: any) => {
          const progressMessages = {
            parsing: '🔍 Understanding your request...',
            parsed: `✅ Request understood: ${data?.intent || 'processing'}`,
            generating: '⚙️ Generating code...',
            generated: '✅ Code generated successfully!',
            applying: '📝 Applying changes...',
            applied: '✅ Changes applied!',
            error: '❌ An error occurred'
          };

          updateMessage(processingMessage.id, {
            content: progressMessages[step as keyof typeof progressMessages] || `Processing: ${step}`
          });
        }
      });

      // Remove processing message
      setMessages(prev => prev.filter(msg => msg.id !== processingMessage.id));

      if (!result.success) {
        addSystemMessage(`❌ ${result.error}`, 'error');
        return;
      }

      // Show parsing results
      if (result.parsedRequest) {
        const parseContent = `**🎯 Request Analysis:**
• **Intent:** ${result.parsedRequest.intent}
• **Target:** ${result.parsedRequest.targetFile || 'Auto-detect'}
• **Confidence:** ${(result.parsedRequest.confidence * 100).toFixed(1)}%
• **Complexity:** ${result.parsedRequest.estimatedComplexity || 'medium'}

${result.parsedRequest.confidence < 0.7 ? 
  '⚠️ Confidence is moderate. I\'ll do my best with the interpretation.' : 
  '✅ High confidence - proceeding with code generation!'}`;

        addMessage('assistant', parseContent, { 
          type: 'text',
          parsedRequest: result.parsedRequest 
        });
      }

      // Show generated code with preview
      if (result.generatedCode) {
        const codeContent = typeof result.generatedCode.content === 'string' 
          ? result.generatedCode.content 
          : JSON.stringify(result.generatedCode.content, null, 2);

        const codePreviewContent = `**🎉 Code Generated Successfully!**

${result.generatedCode.diffSummary || 'Code changes are ready for your review.'}

${result.generatedCode.explanations ? 
  `**What this does:**\n${result.generatedCode.explanations.map(exp => `• ${exp}`).join('\n')}` : 
  ''}

${result.generatedCode.warnings?.length ? 
  `\n**⚠️ Important Notes:**\n${result.generatedCode.warnings.map(w => `• ${w}`).join('\n')}` : 
  ''}

**Review the code below and let me know if you want to apply it!**`;

        addMessage('assistant', codePreviewContent, {
          type: 'code_preview',
          codeContent,
          diffSummary: result.generatedCode.diffSummary,
          generatedCode: result.generatedCode,
          pendingApproval: true
        });

        // Set pending approval state
        setPendingApproval({
          code: result.generatedCode,
          request: result.parsedRequest
        });
      }

    } catch (error) {
      setMessages(prev => prev.filter(msg => msg.id !== processingMessage.id));
      throw error;
    }
  };

  const handleChatRequest = async (message: string) => {
    const processingMessage = addMessage('system', '💭 Thinking...');

    try {
      const response = await fetch(`${API_URL}/api/obsidian/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          conversation_id: conversationId,
          mode: currentMode,
          context: { projectPath }
        })
      });

      if (!response.ok) {
        throw new Error(`Chat failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      // Remove processing message and add response
      setMessages(prev => prev.filter(msg => msg.id !== processingMessage.id));
      addMessage('assistant', result.response || result.data?.response || 'No response received');

    } catch (error) {
      setMessages(prev => prev.filter(msg => msg.id !== processingMessage.id));
      throw error;
    }
  };

  const handleApprovalResponse = async (response: string) => {
    if (!pendingApproval) return;

    if (['yes', 'y', 'apply', 'approve', 'ok'].includes(response)) {
      // Apply the code
      setIsProcessing(true);
      const applyingMessage = addMessage('system', '📝 Applying changes to your codebase...');

      try {
        if (!apiRef.current) throw new Error('API client not initialized');

        const result = await apiRef.current.applyChanges({
          changes: {
            type: pendingApproval.code.type,
            content: pendingApproval.code.content,
            targetFile: pendingApproval.request?.targetFile,
            projectPath
          },
          metadata: {
            intent: pendingApproval.request?.intent,
            description: pendingApproval.request?.description,
            diffSummary: pendingApproval.code.diffSummary
          }
        });

        // Remove applying message
        setMessages(prev => prev.filter(msg => msg.id !== applyingMessage.id));

        if (result.success) {
          addSystemMessage('✅ **Changes Applied Successfully!**\n\nYour codebase has been updated. The changes are now live!', 'success');
          onCodeApplied?.(result);
        } else {
          addSystemMessage(`❌ **Failed to apply changes:** ${result.message}`, 'error');
        }

      } catch (error) {
        setMessages(prev => prev.filter(msg => msg.id !== applyingMessage.id));
        addSystemMessage(
          `❌ **Error applying changes:** ${error instanceof Error ? error.message : 'Unknown error'}`,
          'error'
        );
      } finally {
        setPendingApproval(null);
        setIsProcessing(false);
      }

    } else if (['no', 'n', 'reject', 'cancel'].includes(response)) {
      // Reject the code
      setPendingApproval(null);
      addSystemMessage('❌ **Changes Rejected**\n\nNo problem! Feel free to request modifications or try a different approach. What would you like to do instead?');

    } else {
      // Unclear response
      addSystemMessage('🤔 I didn\'t understand your response. Please type:\n• **"yes"** or **"apply"** to apply the changes\n• **"no"** or **"reject"** to cancel\n\nWhat would you like to do?');
    }
  };

  // === Keyboard Shortcuts ===
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // === Mode Switch ===
  const switchMode = (newMode: 'ask' | 'agent' | 'dev') => {
    setCurrentMode(newMode);
    setPendingApproval(null);
    
    const modeMessages = {
      ask: 'Switched to **Ask Mode** - Quick questions and simple assistance',
      agent: 'Switched to **Agent Mode** - Complex workflows and analysis',  
      dev: 'Switched to **Development Mode** - Code generation and modification'
    };

    addSystemMessage(`🔄 ${modeMessages[newMode]}`);
  };

  // === Render Helpers ===
  const renderMessage = (message: ChatMessage) => {
    const isUser = message.role === 'user';
    const isSystem = message.role === 'system';
    
    return (
      <div key={message.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
        <div className={`max-w-[85%] rounded-lg p-4 ${
          isUser 
            ? 'bg-blue-600 text-white' 
            : isSystem
            ? message.metadata?.type === 'error'
              ? 'bg-red-100 text-red-800 border border-red-200'
              : message.metadata?.type === 'success'
              ? 'bg-green-100 text-green-800 border border-green-200'
              : 'bg-gray-100 text-gray-800 border border-gray-200'
            : 'bg-white text-gray-900 border border-gray-200 shadow-sm'
        }`}>
          <div className="whitespace-pre-wrap">{message.content}</div>
          
          {/* Code Preview */}
          {message.metadata?.type === 'code_preview' && message.metadata.codeContent && (
            <div className="mt-4 bg-gray-900 rounded-lg p-4 border">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm font-medium text-gray-300">Generated Code</span>
                <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">Preview</span>
              </div>
              <pre className="text-sm text-gray-300 overflow-x-auto max-h-64 overflow-y-auto">
                <code>{message.metadata.codeContent}</code>
              </pre>
              
              {message.metadata.pendingApproval && (
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => handleApprovalResponse('yes')}
                    disabled={isProcessing}
                    className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition disabled:opacity-50"
                  >
                    {isProcessing ? 'Applying...' : 'Apply Changes ✅'}
                  </button>
                  <button
                    onClick={() => handleApprovalResponse('no')}
                    disabled={isProcessing}
                    className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition disabled:opacity-50"
                  >
                    Reject ❌
                  </button>
                </div>
              )}
            </div>
          )}
          
          <div className="text-xs opacity-70 mt-2">
            {message.timestamp.toLocaleTimeString()}
          </div>
        </div>
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-5xl h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <span className="text-2xl">
                {currentMode === 'dev' ? '🛠️' : currentMode === 'agent' ? '🤖' : '💬'}
              </span>
              <div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {currentMode === 'dev' ? 'Development Chat' : 'AI Assistant'}
                </h2>
                <p className="text-sm text-gray-600">
                  {currentMode === 'dev' 
                    ? 'Natural language code generation'
                    : 'AI-powered assistance and analysis'
                  }
                </p>
              </div>
            </div>

            {/* Mode Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              {[
                { mode: 'ask' as const, label: 'Ask', icon: '💬' },
                { mode: 'agent' as const, label: 'Agent', icon: '🤖' },
                { mode: 'dev' as const, label: 'Dev', icon: '🛠️' }
              ].map(({ mode, label, icon }) => (
                <button
                  key={mode}
                  onClick={() => switchMode(mode)}
                  className={`px-3 py-1 text-sm rounded transition flex items-center gap-1 ${
                    currentMode === mode 
                      ? 'bg-blue-600 text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <span className="text-xs">{icon}</span>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Connection Status */}
            {currentMode === 'dev' && (
              <div className={`flex items-center gap-2 text-xs px-2 py-1 rounded ${
                connectionStatus === 'connected' 
                  ? 'bg-green-100 text-green-700'
                  : connectionStatus === 'connecting'
                  ? 'bg-yellow-100 text-yellow-700'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-green-500' :
                  connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-gray-400'
                }`} />
                {connectionStatus}
              </div>
            )}

            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-2xl"
            >
              ×
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4">
          {messages.map(renderMessage)}
          
          {isProcessing && (
            <div className="flex justify-start mb-4">
              <div className="bg-gray-100 rounded-lg p-4 flex items-center gap-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600" />
                <span className="text-sm text-gray-600">AI is working...</span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex gap-3">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                pendingApproval 
                  ? "Type 'yes' to apply or 'no' to reject the changes..."
                  : currentMode === 'dev'
                  ? "Describe the code changes you want... (Ctrl+Enter to send)"
                  : "Ask me anything... (Ctrl+Enter to send)"
              }
              className="flex-1 resize-none rounded-lg border border-gray-300 px-3 py-2 
                       focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={2}
              disabled={isProcessing}
            />
            <button
              onClick={handleSendMessage}
              disabled={!input.trim() || isProcessing}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 
                       transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Send
            </button>
          </div>
          
          <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
            <span>
              {currentMode === 'dev' 
                ? '💡 Be specific about files and requirements for best results'
                : '💭 Ask questions, request analysis, or get help with anything'
              }
            </span>
            <span>Ctrl+Enter to send</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatModal;
