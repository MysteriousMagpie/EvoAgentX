export default function Loader() {
  return (
    <div className="animate-spin rounded-full h-6 w-6 border-2 border-t-transparent mx-auto" />
  );
}
