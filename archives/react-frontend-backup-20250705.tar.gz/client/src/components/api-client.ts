/**
 * API Client for Conversational Development Interface
 * 
 * This module provides the API integration for the chat-based development workflow:
 * 1. Parse development requests from natural language
 * 2. Generate code using EvoAgentX agents  
 * 3. Apply changes to the codebase
 * 4. Handle real-time updates via WebSocket
 */

import { API_URL } from '../api';

// === Type Definitions ===

export interface ParseDevRequestParams {
  message: string;
  context?: {
    projectPath?: string;
    currentFile?: string;
    selection?: string;
    parseType?: 'development_request' | 'bug_fix' | 'feature_request';
    mode?: 'conversational' | 'batch';
  };
}

export interface ParsedDevRequest {
  intent: 'create' | 'modify' | 'delete' | 'refactor' | 'add_feature' | 'fix_bug' | 'optimize' | 'test' | 'document';
  targetFile?: string;
  description: string;
  confidence: number;
  requiredFiles?: string[];
  suggestedApproach?: string;
  estimatedComplexity?: 'low' | 'medium' | 'high';
  dependencies?: string[];
  riskFactors?: string[];
}

export interface CodeGenerationRequest {
  agent_type: 'code_generator' | 'refactor_agent' | 'test_generator' | 'documentation_agent';
  request: {
    intent: string;
    targetFile?: string;
    description: string;
    context?: {
      projectPath?: string;
      requiredFiles?: string[];
      approach?: string;
      constraints?: string[];
      mode?: 'conversational' | 'batch';
    };
  };
}

export interface GeneratedCode {
  type: 'patch' | 'full_file' | 'multiple_files' | 'directory_structure';
  content: string | Record<string, string>;
  diffSummary?: string;
  explanations?: string[];
  warnings?: string[];
  dependencies?: string[];
  testSuggestions?: string[];
  rollbackInfo?: {
    backupPath?: string;
    restoreCommands?: string[];
  };
}

export interface ApplyChangesRequest {
  changes: {
    type: GeneratedCode['type'];
    content: GeneratedCode['content'];
    targetFile?: string;
    projectPath?: string;
  };
  metadata?: {
    intent?: string;
    description?: string;
    diffSummary?: string;
    authorInfo?: {
      source: 'conversational_dev';
      timestamp: string;
      userRequest: string;
    };
  };
  options?: {
    createBackup?: boolean;
    validateSyntax?: boolean;
    runTests?: boolean;
    autoReload?: boolean;
  };
}

export interface ApplyChangesResponse {
  success: boolean;
  filesModified?: string[];
  backupCreated?: string;
  validationResults?: {
    syntaxValid?: boolean;
    testsPass?: boolean;
    lintResults?: any;
  };
  reloadRequired?: boolean;
  message?: string;
}

// === Core API Client Class ===

export class ConversationalDevAPI {
  private baseUrl: string;
  private headers: Record<string, string>;

  constructor(baseUrl: string = API_URL) {
    this.baseUrl = baseUrl;
    this.headers = {
      'Content-Type': 'application/json',
    };
  }

  /**
   * Parse a natural language development request
   */
  async parseDevRequest(params: ParseDevRequestParams): Promise<ParsedDevRequest> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/intelligence/parse`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(params)
      });

      if (!response.ok) {
        throw new Error(`Parse request failed: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      return result.data || result;
    } catch (error) {
      console.error('Error parsing dev request:', error);
      // Return fallback parsing
      return {
        intent: 'modify',
        description: params.message,
        confidence: 0.3,
        suggestedApproach: 'Manual review required - could not parse automatically',
        estimatedComplexity: 'medium',
        riskFactors: ['Automatic parsing failed', 'Manual review recommended']
      };
    }
  }

  /**
   * Generate code based on parsed development request
   */
  async generateCode(request: CodeGenerationRequest): Promise<GeneratedCode> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/agents/execute`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(request)
      });

      if (!response.ok) {
        throw new Error(`Code generation failed: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      const generatedCode = result.data?.generatedCode || result.generatedCode;
      
      if (!generatedCode) {
        throw new Error('No code generated in response');
      }

      return generatedCode;
    } catch (error) {
      console.error('Error generating code:', error);
      throw new Error(`Code generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Apply generated code changes to the codebase
   */
  async applyChanges(request: ApplyChangesRequest): Promise<ApplyChangesResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/workflow/apply-changes`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          ...request,
          metadata: {
            ...request.metadata,
            authorInfo: {
              source: 'conversational_dev',
              timestamp: new Date().toISOString(),
              userRequest: request.metadata?.description || 'Conversational development request'
            }
          },
          options: {
            createBackup: true,
            validateSyntax: true,
            autoReload: true,
            ...request.options
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Apply changes failed: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      return result.data || result;
    } catch (error) {
      console.error('Error applying changes:', error);
      return {
        success: false,
        message: `Failed to apply changes: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  /**
   * Get project context and file structure
   */
  async getProjectContext(projectPath: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/vault/context`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          project_path: projectPath,
          include_structure: true,
          include_dependencies: true
        })
      });

      if (!response.ok) {
        throw new Error(`Get context failed: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting project context:', error);
      return null;
    }
  }

  /**
   * Validate generated code before applying
   */
  async validateCode(code: string, fileType: string): Promise<{ valid: boolean; errors?: string[] }> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/validate-code`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          code,
          file_type: fileType,
          validation_type: 'syntax'
        })
      });

      if (!response.ok) {
        // If validation endpoint doesn't exist, assume valid
        return { valid: true };
      }

      return await response.json();
    } catch (error) {
      console.warn('Code validation not available:', error);
      return { valid: true };
    }
  }

  /**
   * Get conversation history for development chats
   */
  async getConversationHistory(conversationId: string): Promise<any[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/conversation/history`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          conversation_id: conversationId,
          limit: 50
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get conversation history');
      }

      const result = await response.json();
      return result.data?.messages || result.messages || [];
    } catch (error) {
      console.error('Error getting conversation history:', error);
      return [];
    }
  }

  /**
   * Save development session for future reference
   */
  async saveDevSession(session: {
    sessionId: string;
    messages: any[];
    codeChanges: any[];
    projectPath: string;
  }): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/obsidian/dev-sessions/save`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(session)
      });

      return response.ok;
    } catch (error) {
      console.error('Error saving dev session:', error);
      return false;
    }
  }
}

// === Utility Functions ===

/**
 * Complete development workflow: parse -> generate -> apply
 */
export async function executeDevWorkflow(
  userMessage: string,
  options: {
    projectPath?: string;
    autoApply?: boolean;
    onProgress?: (step: string, data?: any) => void;
  } = {}
): Promise<{
  success: boolean;
  parsedRequest?: ParsedDevRequest;
  generatedCode?: GeneratedCode;
  appliedChanges?: ApplyChangesResponse;
  error?: string;
}> {
  const api = new ConversationalDevAPI();
  const { projectPath = '/default/project', autoApply = false, onProgress } = options;

  try {
    // Step 1: Parse request
    onProgress?.('parsing', { message: userMessage });
    const parsedRequest = await api.parseDevRequest({
      message: userMessage,
      context: { projectPath, parseType: 'development_request' }
    });

    onProgress?.('parsed', parsedRequest);

    if (parsedRequest.confidence < 0.3) {
      return {
        success: false,
        parsedRequest,
        error: 'Low confidence in parsing request. Please be more specific.'
      };
    }

    // Step 2: Generate code
    onProgress?.('generating', parsedRequest);
    const generatedCode = await api.generateCode({
      agent_type: 'code_generator',
      request: {
        intent: parsedRequest.intent,
        targetFile: parsedRequest.targetFile,
        description: parsedRequest.description,
        context: {
          projectPath,
          requiredFiles: parsedRequest.requiredFiles,
          approach: parsedRequest.suggestedApproach
        }
      }
    });

    onProgress?.('generated', generatedCode);

    // Step 3: Apply changes (if auto-apply is enabled)
    let appliedChanges: ApplyChangesResponse | undefined;
    if (autoApply) {
      onProgress?.('applying', generatedCode);
      appliedChanges = await api.applyChanges({
        changes: {
          type: generatedCode.type,
          content: generatedCode.content,
          targetFile: parsedRequest.targetFile,
          projectPath
        },
        metadata: {
          intent: parsedRequest.intent,
          description: parsedRequest.description,
          diffSummary: generatedCode.diffSummary
        }
      });

      onProgress?.('applied', appliedChanges);
    }

    return {
      success: true,
      parsedRequest,
      generatedCode,
      appliedChanges
    };

  } catch (error) {
    onProgress?.('error', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

/**
 * Initialize WebSocket connection for real-time development updates
 */
export function initializeDevWebSocket(
  vaultId: string = 'default',
  onMessage?: (message: any) => void
): WebSocket | null {
  try {
    const wsUrl = API_URL.replace('http', 'ws') + `/ws/obsidian?vault_id=${vaultId}`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log('Connected to development WebSocket');
      // Send identification
      ws.send(JSON.stringify({
        type: 'handshake',
        client_type: 'conversational_dev',
        vault_id: vaultId
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        onMessage?.(message);
        
        // Handle specific development-related messages
        if (message.type === 'code_applied') {
          console.log('Code changes applied:', message.data);
        } else if (message.type === 'validation_result') {
          console.log('Code validation result:', message.data);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    ws.onclose = () => {
      console.log('Development WebSocket disconnected');
    };

    ws.onerror = (error) => {
      console.error('Development WebSocket error:', error);
    };

    return ws;
  } catch (error) {
    console.error('Failed to initialize development WebSocket:', error);
    return null;
  }
}

// === Default Export ===
export default ConversationalDevAPI;
