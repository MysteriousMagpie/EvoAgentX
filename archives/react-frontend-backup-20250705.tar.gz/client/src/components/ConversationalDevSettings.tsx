import React, { useState, useEffect } from 'react';
import { API_URL } from '../api';

interface ConversationalDevSettingsProps {
  onSettingsChange?: (settings: ConversationalDevSettings) => void;
}

interface ConversationalDevSettings {
  // General Settings
  enabled: boolean;
  defaultMode: 'ask' | 'agent' | 'dev';
  autoApplyChanges: boolean;
  createBackups: boolean;
  
  // Code Generation Settings
  preferredFramework: 'react' | 'vue' | 'angular' | 'auto';
  useTypeScript: boolean;
  codeStyle: 'standard' | 'prettier' | 'eslint' | 'custom';
  includeComments: boolean;
  includeTests: boolean;
  
  // Safety Settings
  validateSyntax: boolean;
  runLinting: boolean;
  requireApproval: boolean;
  maxFileSize: number; // KB
  restrictedPaths: string[];
  
  // UI Settings
  showCodePreview: boolean;
  highlightSyntax: boolean;
  autoScroll: boolean;
  showTimestamps: boolean;
  
  // Advanced Settings
  apiEndpoint: string;
  maxTokens: number;
  temperature: number;
  enableWebSocket: boolean;
  debugMode: boolean;
}

const DEFAULT_SETTINGS: ConversationalDevSettings = {
  // General
  enabled: true,
  defaultMode: 'dev',
  autoApplyChanges: false,
  createBackups: true,
  
  // Code Generation
  preferredFramework: 'auto',
  useTypeScript: true,
  codeStyle: 'prettier',
  includeComments: true,
  includeTests: false,
  
  // Safety
  validateSyntax: true,
  runLinting: true,
  requireApproval: true,
  maxFileSize: 100, // 100KB
  restrictedPaths: ['node_modules/', '.git/', 'dist/', 'build/'],
  
  // UI
  showCodePreview: true,
  highlightSyntax: true,
  autoScroll: true,
  showTimestamps: true,
  
  // Advanced
  apiEndpoint: API_URL,
  maxTokens: 4000,
  temperature: 0.7,
  enableWebSocket: true,
  debugMode: false
};

export const ConversationalDevSettings: React.FC<ConversationalDevSettingsProps> = ({
  onSettingsChange
}) => {
  const [settings, setSettings] = useState<ConversationalDevSettings>(DEFAULT_SETTINGS);
  const [activeTab, setActiveTab] = useState<'general' | 'generation' | 'safety' | 'ui' | 'advanced'>('general');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Load settings from localStorage on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('conversational-dev-settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    }
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('conversational-dev-settings', JSON.stringify(settings));
    onSettingsChange?.(settings);
  }, [settings, onSettingsChange]);

  const updateSetting = <K extends keyof ConversationalDevSettings>(
    key: K,
    value: ConversationalDevSettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const testConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const response = await fetch(`${settings.apiEndpoint}/api/obsidian/health`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });

      if (response.ok) {
        const data = await response.json();
        setTestResult({
          success: true,
          message: `✅ Connected successfully! Server status: ${data.status || 'healthy'}`
        });
      } else {
        setTestResult({
          success: false,
          message: `❌ Connection failed: ${response.status} ${response.statusText}`
        });
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: `❌ Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setIsTesting(false);
    }
  };

  const resetToDefaults = () => {
    if (confirm('Are you sure you want to reset all settings to defaults?')) {
      setSettings(DEFAULT_SETTINGS);
    }
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'conversational-dev-settings.json';
    link.click();
    
    URL.revokeObjectURL(url);
  };

  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string);
        setSettings({ ...DEFAULT_SETTINGS, ...imported });
      } catch (error) {
        alert('Failed to import settings: Invalid file format');
      }
    };
    reader.readAsText(file);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return (
          <div className="space-y-6">
            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.enabled}
                  onChange={(e) => updateSetting('enabled', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Enable Conversational Development</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Turn on/off the entire conversational development interface
              </p>
            </div>

            <div>
              <label className="block font-medium mb-2">Default Mode</label>
              <select
                value={settings.defaultMode}
                onChange={(e) => updateSetting('defaultMode', e.target.value as any)}
                className="w-full p-2 border border-gray-300 rounded"
              >
                <option value="ask">Ask Mode - Quick questions</option>
                <option value="agent">Agent Mode - Complex workflows</option>
                <option value="dev">Development Mode - Code generation</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.autoApplyChanges}
                  onChange={(e) => updateSetting('autoApplyChanges', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Auto-apply code changes</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                ⚠️ Automatically apply generated code without manual approval (not recommended)
              </p>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.createBackups}
                  onChange={(e) => updateSetting('createBackups', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Create backups before applying changes</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Automatically backup files before modifying them
              </p>
            </div>
          </div>
        );

      case 'generation':
        return (
          <div className="space-y-6">
            <div>
              <label className="block font-medium mb-2">Preferred Framework</label>
              <select
                value={settings.preferredFramework}
                onChange={(e) => updateSetting('preferredFramework', e.target.value as any)}
                className="w-full p-2 border border-gray-300 rounded"
              >
                <option value="auto">Auto-detect</option>
                <option value="react">React</option>
                <option value="vue">Vue</option>
                <option value="angular">Angular</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.useTypeScript}
                  onChange={(e) => updateSetting('useTypeScript', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Use TypeScript</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Generate TypeScript code with proper type definitions
              </p>
            </div>

            <div>
              <label className="block font-medium mb-2">Code Style</label>
              <select
                value={settings.codeStyle}
                onChange={(e) => updateSetting('codeStyle', e.target.value as any)}
                className="w-full p-2 border border-gray-300 rounded"
              >
                <option value="standard">Standard</option>
                <option value="prettier">Prettier</option>
                <option value="eslint">ESLint</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.includeComments}
                  onChange={(e) => updateSetting('includeComments', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Include explanatory comments</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.includeTests}
                  onChange={(e) => updateSetting('includeTests', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Generate unit tests</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Automatically generate basic unit tests for new code
              </p>
            </div>
          </div>
        );

      case 'safety':
        return (
          <div className="space-y-6">
            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.validateSyntax}
                  onChange={(e) => updateSetting('validateSyntax', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Validate syntax before applying</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.runLinting}
                  onChange={(e) => updateSetting('runLinting', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Run linting checks</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.requireApproval}
                  onChange={(e) => updateSetting('requireApproval', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Require manual approval</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Always ask for confirmation before applying code changes
              </p>
            </div>

            <div>
              <label className="block font-medium mb-2">
                Maximum file size for modification ({settings.maxFileSize} KB)
              </label>
              <input
                type="range"
                min="10"
                max="1000"
                value={settings.maxFileSize}
                onChange={(e) => updateSetting('maxFileSize', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>10 KB</span>
                <span>1000 KB</span>
              </div>
            </div>

            <div>
              <label className="block font-medium mb-2">Restricted Paths</label>
              <textarea
                value={settings.restrictedPaths.join('\n')}
                onChange={(e) => updateSetting('restrictedPaths', e.target.value.split('\n').filter(Boolean))}
                className="w-full p-2 border border-gray-300 rounded h-24"
                placeholder="node_modules/&#10;.git/&#10;dist/"
              />
              <p className="text-sm text-gray-600 mt-1">
                One path per line. Files in these paths cannot be modified.
              </p>
            </div>
          </div>
        );

      case 'ui':
        return (
          <div className="space-y-6">
            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.showCodePreview}
                  onChange={(e) => updateSetting('showCodePreview', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Show code preview</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.highlightSyntax}
                  onChange={(e) => updateSetting('highlightSyntax', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Syntax highlighting</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.autoScroll}
                  onChange={(e) => updateSetting('autoScroll', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Auto-scroll to new messages</span>
              </label>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.showTimestamps}
                  onChange={(e) => updateSetting('showTimestamps', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Show message timestamps</span>
              </label>
            </div>
          </div>
        );

      case 'advanced':
        return (
          <div className="space-y-6">
            <div>
              <label className="block font-medium mb-2">API Endpoint</label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={settings.apiEndpoint}
                  onChange={(e) => updateSetting('apiEndpoint', e.target.value)}
                  className="flex-1 p-2 border border-gray-300 rounded"
                  placeholder="http://localhost:8000"
                />
                <button
                  onClick={testConnection}
                  disabled={isTesting}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                >
                  {isTesting ? 'Testing...' : 'Test'}
                </button>
              </div>
              {testResult && (
                <p className={`text-sm mt-1 ${testResult.success ? 'text-green-600' : 'text-red-600'}`}>
                  {testResult.message}
                </p>
              )}
            </div>

            <div>
              <label className="block font-medium mb-2">
                Max Tokens ({settings.maxTokens})
              </label>
              <input
                type="range"
                min="1000"
                max="8000"
                value={settings.maxTokens}
                onChange={(e) => updateSetting('maxTokens', parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>1000</span>
                <span>8000</span>
              </div>
            </div>

            <div>
              <label className="block font-medium mb-2">
                Temperature ({settings.temperature})
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.temperature}
                onChange={(e) => updateSetting('temperature', parseFloat(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0 (Focused)</span>
                <span>1 (Creative)</span>
              </div>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.enableWebSocket}
                  onChange={(e) => updateSetting('enableWebSocket', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Enable WebSocket connection</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Real-time updates and notifications
              </p>
            </div>

            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.debugMode}
                  onChange={(e) => updateSetting('debugMode', e.target.checked)}
                  className="w-4 h-4 text-blue-600"
                />
                <span className="font-medium">Debug mode</span>
              </label>
              <p className="text-sm text-gray-600 mt-1">
                Show detailed logs and debug information
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg max-w-4xl mx-auto">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-semibold text-gray-900 flex items-center gap-3">
          <span className="text-3xl">⚙️</span>
          Conversational Development Settings
        </h2>
        <p className="text-gray-600 mt-2">
          Configure how the AI assists with code generation and modification
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 px-6">
          {[
            { id: 'general' as const, label: 'General', icon: '🔧' },
            { id: 'generation' as const, label: 'Code Generation', icon: '🚀' },
            { id: 'safety' as const, label: 'Safety', icon: '🛡️' },
            { id: 'ui' as const, label: 'Interface', icon: '🎨' },
            { id: 'advanced' as const, label: 'Advanced', icon: '⚡' }
          ].map(({ id, label, icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                activeTab === id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <span>{icon}</span>
              {label}
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="p-6">
        {renderTabContent()}
      </div>

      {/* Footer */}
      <div className="p-6 bg-gray-50 border-t border-gray-200 flex justify-between">
        <div className="flex gap-3">
          <button
            onClick={exportSettings}
            className="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50"
          >
            Export Settings
          </button>
          
          <label className="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 cursor-pointer">
            Import Settings
            <input
              type="file"
              accept=".json"
              onChange={importSettings}
              className="hidden"
            />
          </label>
        </div>

        <div className="flex gap-3">
          <button
            onClick={resetToDefaults}
            className="px-4 py-2 text-red-600 border border-red-300 rounded hover:bg-red-50"
          >
            Reset to Defaults
          </button>
          
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Apply & Reload
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConversationalDevSettings;
