# Code Citations

## License: unknown
https://github.com/Thee-sage/web3-Maze-game/tree/e52c19d6e22e1d98cd6d12d181690fdba32256d6/src/pages/maze/vite-project/src/App.jsx

```
) => {
       socket.on("connect", () => {
         console.log("Connected to Socket.IO server");
       });

       socket.on("disconnect", () => {
         console.log("Disconnected from Socket
```

