import { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AppLayout from './components/AppLayout';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Planner from './pages/Planner';
import CodeInterpreter from './pages/CodeInterpreter';
import { getSocket } from './socket';
import ChatModal from './components/ChatModal';
import ConversationalDevSettings from './components/ConversationalDevSettings';

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [devSettings, setDevSettings] = useState<any>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    const socket = getSocket();
    socket.on('connect', () => {
      console.log('Connected to Socket.IO server');
    });
    socket.on('disconnect', () => {
      console.log('Disconnected from Socket.IO server');
    });
    socket.on('progress', (message) => {
      console.log('Progress event:', message);
    });
    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('progress');
    };
  }, []);

  // === Global Keyboard Shortcuts ===
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + Shift + D = Open Development Chat
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        setShowChatModal(true);
      }
      
      // Ctrl/Cmd + Shift + S = Open Settings
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'S') {
        e.preventDefault();
        setShowSettings(true);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleCodeApplied = (changes: any) => {
    console.log('Code changes applied:', changes);
    // Here you could trigger UI updates, show notifications, etc.
  };

  return (
    <BrowserRouter>
      <AppLayout darkMode={darkMode} setDarkMode={setDarkMode}>
        {/* Main Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/planner" element={<Planner />} />
          <Route path="/interpreter" element={<CodeInterpreter />} />
          <Route 
            path="/dev-settings" 
            element={
              <div className="p-6">
                <ConversationalDevSettings onSettingsChange={setDevSettings} />
              </div>
            } 
          />
        </Routes>

        {/* Floating Development Chat Button */}
        {!showChatModal && devSettings?.enabled !== false && (
          <button
            onClick={() => setShowChatModal(true)}
            className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-all z-40 group"
            title="Open Development Chat (Ctrl+Shift+D)"
          >
            <span className="text-2xl">🛠️</span>
            <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-900 text-white text-sm rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              Development Chat
            </div>
          </button>
        )}

        {/* Conversational Development Chat Modal */}
        <ChatModal
          isOpen={showChatModal}
          onClose={() => setShowChatModal(false)}
          mode="development"
          projectPath="/current/project"
          onCodeApplied={handleCodeApplied}
        />

        {/* Settings Modal */}
        {showSettings && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-auto">
              <div className="flex justify-between items-center p-4 border-b">
                <h2 className="text-xl font-semibold">Development Settings</h2>
                <button
                  onClick={() => setShowSettings(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
              <ConversationalDevSettings onSettingsChange={setDevSettings} />
            </div>
          </div>
        )}
      </AppLayout>
    </BrowserRouter>
  );
}

