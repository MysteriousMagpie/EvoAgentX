import { InterpreterSelector } from '../components/InterpreterSelector';

export default function CodeInterpreter() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto mt-8">
      {/* OpenAI Code Interpreter Section */}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold mb-2">🤖 OpenAI Code Interpreter</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Analyze your code and get intelligent interpreter recommendations. 
          Paste or upload your code to get started.
        </p>
        <InterpreterSelector 
          code=""
          onInterpreterChange={(interpreter) => {
            console.log('Interpreter changed:', interpreter);
          }}
          onExecute={(code, interpreter) => {
            console.log('Execute code:', { code, interpreter });
          }}
        />
      </div>

      {/* Features Overview */}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">✨ Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
              🧠 Intelligent Analysis
            </h3>
            <p className="text-blue-700 dark:text-blue-200 text-sm">
              AI-powered code analysis that understands context, dependencies, and optimal interpreter selection.
            </p>
          </div>
          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <h3 className="font-semibold text-green-900 dark:text-green-100 mb-2">
              🎯 Smart Recommendations
            </h3>
            <p className="text-green-700 dark:text-green-200 text-sm">
              Get personalized interpreter recommendations based on your code structure and requirements.
            </p>
          </div>
          <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
            <h3 className="font-semibold text-purple-900 dark:text-purple-100 mb-2">
              🚀 Quick Execution
            </h3>
            <p className="text-purple-700 dark:text-purple-200 text-sm">
              Execute code snippets directly with the recommended interpreter for instant feedback.
            </p>
          </div>
          <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
            <h3 className="font-semibold text-orange-900 dark:text-orange-100 mb-2">
              📊 Visual Insights
            </h3>
            <p className="text-orange-700 dark:text-orange-200 text-sm">
              Rich analysis results with confidence metrics, performance hints, and visual feedback.
            </p>
          </div>
        </div>
      </div>

      {/* Usage Guide */}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">📚 How to Use</h2>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
              1
            </div>
            <div>
              <h3 className="font-semibold mb-1">Paste Your Code</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Copy and paste your code into the editor, or upload a file to analyze.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
              2
            </div>
            <div>
              <h3 className="font-semibold mb-1">Get Analysis</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Click "Analyze Code" to get intelligent interpreter recommendations and insights.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
              3
            </div>
            <div>
              <h3 className="font-semibold mb-1">Execute & Refine</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Use the recommended interpreter to execute your code and get immediate feedback.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
