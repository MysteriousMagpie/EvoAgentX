import Planner from '../components/Planner';

export default Planner;
