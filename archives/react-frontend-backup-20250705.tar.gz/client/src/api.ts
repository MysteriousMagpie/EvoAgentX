// Centralized API URL helper
export const API_URL = import.meta.env.VITE_API_URL || "http://192.168.10.51:8000";
